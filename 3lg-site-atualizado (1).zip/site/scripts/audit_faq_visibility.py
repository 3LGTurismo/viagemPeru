#!/usr/bin/env python3
"""
Auditoria de consistência FAQPage — 3LG Turismo
=================================================
Verifica, em todo o site, se cada pergunta declarada em um bloco JSON-LD
"FAQPage" também aparece como TEXTO VISÍVEL na página (fora de tags <script>).

Por que isso importa: o Google exige que o conteúdo marcado com FAQPage
esteja visível na página. Marcação "invisível" (só no JSON-LD, sem
elemento correspondente no HTML renderizado) pode fazer o rich result
ser recusado ou, em casos recorrentes, gerar ação manual por dados
estruturados enganosos.

Uso:
    python3 audit_faq_visibility.py [caminho_raiz_do_site]

Saída:
    Lista, por página, as perguntas presentes no schema que não têm
    correspondência no HTML visível. Saída vazia = tudo consistente.
"""
import re
import sys
import glob
import json

root = sys.argv[1] if len(sys.argv) > 1 else "."

files = glob.glob(f"{root}/**/index.html", recursive=True)
pages_with_issues = {}

for path in sorted(files):
    content = open(path, encoding="utf-8").read()

    script_spans = [
        (m.start(), m.end())
        for m in re.finditer(r'<script type="application/ld\+json">.*?</script>', content, re.S)
    ]

    def in_script(pos):
        return any(s <= pos < e for s, e in script_spans)

    blocks = re.findall(r'<script type="application/ld\+json">(.*?)</script>', content, re.S)
    for b in blocks:
        try:
            data = json.loads(b)
        except Exception:
            continue

        types = data.get("@type")
        if types == "FAQPage" or (isinstance(types, list) and "FAQPage" in types):
            for q in data.get("mainEntity", []):
                name = q.get("name", "")
                found_visible = any(
                    not in_script(m.start()) for m in re.finditer(re.escape(name), content)
                )
                if not found_visible:
                    pages_with_issues.setdefault(path, []).append(name)

if not pages_with_issues:
    print("✅ Nenhuma inconsistência encontrada — todas as perguntas do FAQPage estão visíveis.")
else:
    for path, qs in pages_with_issues.items():
        print(f"\n{path}  ({len(qs)} pergunta(s) sem correspondência visível)")
        for q in qs:
            print(f"   - {q}")
    print(f"\nTOTAL: {len(pages_with_issues)} página(s), {sum(len(v) for v in pages_with_issues.values())} pergunta(s) a corrigir.")
