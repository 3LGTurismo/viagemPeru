/*! 3LG Turismo — lorena.v2.js
 * Chat de qualificação "Lorena". Carregado sob demanda (ver index.html).
 * Sem backend: ao final, encaminha o resumo da conversa para o WhatsApp
 * do consultor humano. Funciona em pt-BR, en e es (lang do <html>).
 */
(function () {
  "use strict";

  var WA_NUMBER = "5511939115806";
  var LANG = (document.documentElement.getAttribute("lang") || "pt-BR").toLowerCase();
  var L = LANG.indexOf("en") === 0 ? "en" : LANG.indexOf("es") === 0 ? "es" : "pt";

  var DEST_NAMES = {
    "caldas-novas": "Caldas Novas",
    "rio-de-janeiro": "Rio de Janeiro",
    "fernando-de-noronha": "Fernando de Noronha",
    "joao-pessoa": "João Pessoa",
    "foz-do-iguacu": "Foz do Iguaçu",
    "lisboa": "Lisboa",
    "buenos-aires": "Buenos Aires",
    "maceio": "Maceió",
    "fortaleza": "Fortaleza",
    "gramado": "Gramado",
    "orlando": "Orlando",
    "balneario-camboriu": "Balneário Camboriú",
    "porto-de-galinhas": "Porto de Galinhas"
  };

  var SUGGESTIONS = {
    "descanso": ["fernando-de-noronha", "porto-de-galinhas", "caldas-novas"],
    "comemoracao": ["buenos-aires", "lisboa", "gramado"],
    "familia": ["orlando", "foz-do-iguacu", "balneario-camboriu"],
    "lua-de-mel": ["fernando-de-noronha", "lisboa", "maceio"],
    "especial": ["rio-de-janeiro", "fortaleza", "joao-pessoa"],
    "default": ["rio-de-janeiro", "gramado", "fernando-de-noronha"]
  };

  var MOTIVO_LABELS = {
    pt: { "descanso": "Descanso", "comemoracao": "Comemoração", "familia": "Férias em família", "lua-de-mel": "Lua de mel", "especial": "Ocasião especial" },
    en: { "descanso": "Relaxing getaway", "comemoracao": "Celebration", "familia": "Family vacation", "lua-de-mel": "Honeymoon", "especial": "Special occasion" },
    es: { "descanso": "Descanso", "comemoracao": "Celebración", "familia": "Vacaciones en familia", "lua-de-mel": "Luna de miel", "especial": "Ocasión especial" }
  };

  var STR = {
    pt: {
      greeting: "Olá, tudo bem? Que bom falar com você! 😊",
      askMotivo: "Me conta uma coisa: essa viagem é para descanso, comemoração, férias em família, lua de mel ou alguma ocasião especial?",
      motivoOptions: ["descanso", "comemoracao", "familia", "lua-de-mel", "especial"],
      askKnowDestino: "Legal! Você já tem um destino em mente ou prefere que eu sugira algumas opções?",
      optTenho: "Já tenho um destino",
      optSugestoes: "Quero sugestões",
      askQualDestino: "Show! Qual destino você está pensando?",
      suggestIntro: "Baseado nisso, algumas ideias que nossos clientes amam:",
      optOutro: "Nenhum desses, quero dizer outro",
      destinoConfirm: function (d) { return d + " é uma escolha e tanto! 🧳"; },
      seeDestination: "Dá uma olhada em ",
      seeDestinationCta: "Ver destino →",
      askDatas: "Quando vocês pretendem viajar? (mês ou período, ex: setembro/2026)",
      askPax: "Quantas pessoas vão viajar?",
      paxOptions: ["1", "2", "3-4", "5+"],
      askCidade: "De qual cidade vocês vão sair?",
      final: "Perfeito! Já tenho tudo que preciso 🙌 Vou buscar as melhores opções personalizadas pra vocês — nossa equipe já vai te chamar no WhatsApp com uma proposta sob medida. ✈️",
      ctaWhatsapp: "Falar com um consultor agora",
      restart: "Começar de novo",
      placeholder: "Digite sua mensagem...",
      waIntro: "Olá! Vim pelo chat da Lorena no site 👋",
      waMotivo: "Motivo", waDestino: "Destino", waDatas: "Datas", waPax: "Pessoas", waCidade: "Saindo de",
      undecided: "ainda decidindo", dash: "-"
    },
    en: {
      greeting: "Hi there! Great to talk to you! 😊",
      askMotivo: "Tell me: is this trip for a relaxing getaway, a celebration, a family vacation, a honeymoon, or a special occasion?",
      motivoOptions: ["descanso", "comemoracao", "familia", "lua-de-mel", "especial"],
      askKnowDestino: "Nice! Do you already have a destination in mind, or would you like a few suggestions?",
      optTenho: "I have a destination",
      optSugestoes: "Suggest some",
      askQualDestino: "Great! What destination are you thinking about?",
      suggestIntro: "Based on that, here are a few ideas our clients love:",
      optOutro: "None of these, let me type one",
      destinoConfirm: function (d) { return d + " is a wonderful choice! 🧳"; },
      seeDestination: "Take a look at ",
      seeDestinationCta: "View destination →",
      askDatas: "When are you planning to travel? (month or period, e.g. September/2026)",
      askPax: "How many people are traveling?",
      paxOptions: ["1", "2", "3-4", "5+"],
      askCidade: "Which city will you be departing from?",
      final: "Perfect! I have everything I need 🙌 I'll look for the best personalized options for you — our team will reach out on WhatsApp shortly with a tailored proposal. ✈️",
      ctaWhatsapp: "Talk to a consultant now",
      restart: "Start over",
      placeholder: "Type your message...",
      waIntro: "Hi! I came from Lorena's chat on the website 👋",
      waMotivo: "Trip for", waDestino: "Destination", waDatas: "Dates", waPax: "Travelers", waCidade: "Departing from",
      undecided: "still deciding", dash: "-"
    },
    es: {
      greeting: "¡Hola! ¡Qué bueno hablar contigo! 😊",
      askMotivo: "Cuéntame: ¿este viaje es para descansar, celebrar, unas vacaciones en familia, luna de miel o alguna ocasión especial?",
      motivoOptions: ["descanso", "comemoracao", "familia", "lua-de-mel", "especial"],
      askKnowDestino: "¡Genial! ¿Ya tienes un destino en mente o prefieres que te sugiera algunas opciones?",
      optTenho: "Ya tengo un destino",
      optSugestoes: "Quiero sugerencias",
      askQualDestino: "¡Buenísimo! ¿Qué destino estás pensando?",
      suggestIntro: "Basado en eso, algunas ideas que nuestros clientes aman:",
      optOutro: "Ninguno de estos, quiero escribir otro",
      destinoConfirm: function (d) { return d + " es una gran elección! 🧳"; },
      seeDestination: "Échale un vistazo a ",
      seeDestinationCta: "Ver destino →",
      askDatas: "¿Cuándo piensan viajar? (mes o período, ej: septiembre/2026)",
      askPax: "¿Cuántas personas van a viajar?",
      paxOptions: ["1", "2", "3-4", "5+"],
      askCidade: "¿Desde qué ciudad van a salir?",
      final: "¡Perfecto! Ya tengo todo lo que necesito 🙌 Voy a buscar las mejores opciones personalizadas para ustedes — nuestro equipo te contactará pronto por WhatsApp con una propuesta a medida. ✈️",
      ctaWhatsapp: "Hablar con un asesor ahora",
      restart: "Empezar de nuevo",
      placeholder: "Escribe tu mensaje...",
      waIntro: "¡Hola! Vengo del chat de Lorena en el sitio web 👋",
      waMotivo: "Motivo", waDestino: "Destino", waDatas: "Fechas", waPax: "Personas", waCidade: "Saliendo de",
      undecided: "aún decidiendo", dash: "-"
    }
  }[L];

  var els = {};
  var answers = { motivo: null, motivoLabel: null, destino: null, datas: null, pax: null, cidade: null };
  var pendingResolve = null;
  var flowStarted = false;

  function q(id) { return document.getElementById(id); }

  function cacheEls() {
    els.messages = q("ln-messages");
    els.options = q("ln-options");
    els.input = q("ln-input");
    els.fab = q("lorena-fab-wrap");
    els.win = q("lorena-window");
    els.callout = q("lorena-callout");
  }

  function scrollBottom() {
    if (els.messages) els.messages.scrollTop = els.messages.scrollHeight;
  }

  function addMessage(text, who) {
    if (!els.messages) return;
    var div = document.createElement("div");
    div.className = "ln-msg " + who;
    div.textContent = text;
    els.messages.appendChild(div);
    scrollBottom();
  }

  function addLinkMessage(prefix, url, ctaLabel, name) {
    if (!els.messages) return;
    var div = document.createElement("div");
    div.className = "ln-msg ln-link";
    var span = document.createElement("span");
    span.textContent = prefix + name + ":";
    span.style.display = "block";
    span.style.fontSize = "12px";
    span.style.color = "var(--text-muted)";
    span.style.marginBottom = "3px";
    var a = document.createElement("a");
    a.href = url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.textContent = ctaLabel;
    div.appendChild(span);
    div.appendChild(a);
    els.messages.appendChild(div);
    scrollBottom();
  }

  function showTyping() {
    if (!els.messages) return;
    var t = document.createElement("div");
    t.className = "ln-msg bot ln-typing";
    t.id = "ln-typing-indicator";
    t.innerHTML = "<span></span><span></span><span></span>";
    els.messages.appendChild(t);
    scrollBottom();
  }

  function hideTyping() {
    var t = q("ln-typing-indicator");
    if (t) t.remove();
  }

  function botSay(text) {
    return new Promise(function (resolve) {
      showTyping();
      var delay = 550 + Math.random() * 450;
      setTimeout(function () {
        hideTyping();
        addMessage(text, "bot");
        resolve();
      }, delay);
    });
  }

  function setOptions(list) {
    if (!els.options) return;
    els.options.innerHTML = "";
    list.forEach(function (opt) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "ln-opt";
      b.textContent = opt.label;
      b.onclick = function () { selectValue(opt.value, opt.label); };
      els.options.appendChild(b);
    });
  }

  function clearOptions() {
    if (els.options) els.options.innerHTML = "";
  }

  function waitForInput() {
    return new Promise(function (resolve) { pendingResolve = resolve; });
  }

  function selectValue(value, label) {
    addMessage(label, "user");
    clearOptions();
    if (pendingResolve) {
      var r = pendingResolve;
      pendingResolve = null;
      r(value);
    }
  }

  function buildWhatsAppText() {
    var lines = [];
    lines.push(STR.waIntro);
    lines.push(STR.waMotivo + ": " + (answers.motivoLabel || STR.dash));
    lines.push(STR.waDestino + ": " + (answers.destino || STR.undecided));
    lines.push(STR.waDatas + ": " + (answers.datas || STR.dash));
    lines.push(STR.waPax + ": " + (answers.pax || STR.dash));
    lines.push(STR.waCidade + ": " + (answers.cidade || STR.dash));
    return lines.join("\n");
  }

  function showFinalCta() {
    if (!els.options) return;
    els.options.innerHTML = "";
    var a = document.createElement("a");
    a.href = "https://wa.me/" + WA_NUMBER + "?text=" + encodeURIComponent(buildWhatsAppText());
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.className = "ln-opt ln-opt-cta";
    a.textContent = STR.ctaWhatsapp;
    els.options.appendChild(a);

    var restart = document.createElement("button");
    restart.type = "button";
    restart.className = "ln-opt ln-opt-ghost";
    restart.textContent = STR.restart;
    restart.onclick = resetFlow;
    els.options.appendChild(restart);
  }

  function resetFlow() {
    answers = { motivo: null, motivoLabel: null, destino: null, datas: null, pax: null, cidade: null };
    if (els.messages) els.messages.innerHTML = "";
    clearOptions();
    runFlow();
  }

  function looksLikeSuggestionRequest(text) {
    return /suger|ideia|n[aã]o sei|idea|not sure|no s[eé]|no lo s[eé]/i.test(text);
  }

  async function runFlow() {
    await botSay(STR.greeting);
    await botSay(STR.askMotivo);
    setOptions(STR.motivoOptions.map(function (key) {
      return { label: MOTIVO_LABELS[L][key], value: key };
    }));
    var motivoChoice = await waitForInput();
    if (MOTIVO_LABELS[L][motivoChoice]) {
      answers.motivo = motivoChoice;
      answers.motivoLabel = MOTIVO_LABELS[L][motivoChoice];
    } else {
      answers.motivo = "default";
      answers.motivoLabel = motivoChoice;
    }

    await botSay(STR.askKnowDestino);
    setOptions([
      { label: STR.optTenho, value: "__tenho__" },
      { label: STR.optSugestoes, value: "__sugestoes__" }
    ]);
    var destinoChoice = await waitForInput();

    var wantsSuggestions = destinoChoice === "__sugestoes__" ||
      (destinoChoice !== "__tenho__" && looksLikeSuggestionRequest(destinoChoice));

    if (wantsSuggestions) {
      await botSay(STR.suggestIntro);
      var slugs = SUGGESTIONS[answers.motivo] || SUGGESTIONS["default"];
      setOptions(slugs.map(function (slug) {
        return { label: DEST_NAMES[slug], value: slug };
      }).concat([{ label: STR.optOutro, value: "__outro__" }]));
      var picked = await waitForInput();
      if (picked === "__outro__") {
        await botSay(STR.askQualDestino);
        answers.destino = await waitForInput();
      } else if (DEST_NAMES[picked]) {
        answers.destino = DEST_NAMES[picked];
        await botSay(STR.destinoConfirm(answers.destino));
        addLinkMessage(STR.seeDestination, "/destinos/" + picked + "/", STR.seeDestinationCta, answers.destino);
      } else {
        answers.destino = picked;
      }
    } else if (destinoChoice === "__tenho__") {
      await botSay(STR.askQualDestino);
      answers.destino = await waitForInput();
      await botSay(STR.destinoConfirm(answers.destino));
    } else {
      // usuário já digitou o nome do destino livremente
      answers.destino = destinoChoice;
      await botSay(STR.destinoConfirm(answers.destino));
    }

    await botSay(STR.askDatas);
    answers.datas = await waitForInput();

    await botSay(STR.askPax);
    setOptions(STR.paxOptions.map(function (p) { return { label: p, value: p }; }));
    answers.pax = await waitForInput();

    await botSay(STR.askCidade);
    answers.cidade = await waitForInput();

    await botSay(STR.final);
    showFinalCta();
  }

  function toggle() {
    if (!els.fab || !els.win) return;
    var opening = !els.fab.classList.contains("open");
    els.fab.classList.toggle("open", opening);
    els.win.classList.toggle("open", opening);
    els.win.setAttribute("aria-hidden", opening ? "false" : "true");
    var emoji = els.fab.querySelector(".bubble-emoji");
    if (emoji) emoji.textContent = opening ? "✕" : "🧳";
    if (els.callout) {
      els.callout.classList.remove("show");
      els.callout.setAttribute("aria-hidden", "true");
      try { localStorage.setItem("lorenaCalloutSeen", "1"); } catch (e) {}
    }
    if (opening) {
      setTimeout(function () { if (els.input) els.input.focus(); }, 320);
    } else {
      els.fab.focus();
    }
  }

  window.lnToggle = toggle;

  window.lnKey = function (e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      window.lnSend();
    }
  };

  window.lnResize = function (el) {
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 120) + "px";
  };

  window.lnSend = function () {
    if (!els.input) return;
    var val = els.input.value.trim();
    if (!val) return;
    els.input.value = "";
    els.input.style.height = "auto";
    addMessage(val, "user");
    clearOptions();
    if (pendingResolve) {
      var r = pendingResolve;
      pendingResolve = null;
      r(val);
    }
  };

  function init() {
    cacheEls();
    if (els.input) els.input.setAttribute("placeholder", STR.placeholder);
    if (!flowStarted) {
      flowStarted = true;
      runFlow();
    }
  }

  init();
  // O carregamento deste arquivo só acontece a partir de um clique real no
  // FAB (ver o loader em index.html). Abrimos a janela imediatamente para
  // refletir esse clique, já que a função lnToggle ainda não existia nele.
  toggle();
})();
