/* =====================================================================
   3LG Turismo — main.v3.js
   ---------------------------------------------------------------------
   MUDANÇAS vs main.v1.js:
   - REMOVIDO: gtag('consent','default') daqui. Agora ele vive no <head>
     de todas as páginas, ANTES do config — ordem correta do Consent Mode.
   - REMOVIDO: segundo carregamento do gtag.js + segundo gtag('config').
     Era isso que dobrava o page_view nas páginas comerciais.
   - MANTIDO: Meta Pixel (carregado no load, como antes).
   - MANTIDO: trackGA4Event, header scroll, menu mobile, banner de cookies.
   - ATUALIZADO: o banner agora grava/atualiza os 4 sinais do Consent
     Mode v2 (analytics_storage, ad_storage, ad_user_data,
     ad_personalization).
   ===================================================================== */
window.dataLayer = window.dataLayer || [];
function gtag(){ dataLayer.push(arguments); }

function trackGA4Event(e, t){
  "function" == typeof gtag && gtag("event", e, Object.assign(
    { page_location: location.href, page_path: location.pathname }, t || {}
  ));
}

/* Meta Pixel — carregado após o load para não pesar a renderização */
window.addEventListener("load", function(){
  var f=window, b=document, e="script", v="https://connect.facebook.net/en_US/fbevents.js", n, t, s;
  if (!f.fbq) {
    n = f.fbq = function(){ n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); };
    if (!f._fbq) f._fbq = n;
    n.push = n; n.loaded = !0; n.version = "2.0"; n.queue = [];
    t = b.createElement(e); t.async = !0; t.src = v;
    s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s);
  }
  fbq("init", "2140450810126671");
  fbq("track", "PageView");
});

/* Header com sombra ao rolar */
const hdr = document.getElementById("site-header");
hdr && window.addEventListener("scroll", () => hdr.classList.toggle("scrolled", window.scrollY > 40), { passive: !0 });

/* Menu mobile (v3.1: suporta #hamburger e #hamburger-btn; overlay opcional) */
const ham = document.getElementById("hamburger") || document.getElementById("hamburger-btn"),
      mob = document.getElementById("mobile-nav"),
      ovl = document.getElementById("mobile-overlay");
function _mobSet(open){
  if(!mob) return;
  mob.classList.toggle("open", open);
  ham && ham.classList.toggle("open", open);
  if(ovl) ovl.classList.toggle("open", open);
  ham && ham.setAttribute("aria-expanded", open ? "true" : "false");
  document.body.style.overflow = open ? "hidden" : "";
}
ham && mob && ham.addEventListener("click", () => _mobSet(!mob.classList.contains("open")));
ovl && ovl.addEventListener("click", () => _mobSet(false));
mob && mob.querySelectorAll("a").forEach(a => a.addEventListener("click", () => _mobSet(false)));
document.addEventListener("keydown", e => { if(e.key === "Escape") _mobSet(false); });

/* Banner de cookies — grava a escolha e atualiza o Consent Mode v2 */
function setCookie(accepted){
  try { localStorage.setItem("3lg_cookie_consent", accepted ? "accepted" : "declined"); } catch(e){}
  var banner = document.getElementById("cookie-banner");
  if (banner) banner.style.transform = "translateY(100%)";
  var v = accepted ? "granted" : "denied";
  if (window.gtag) gtag("consent", "update", {
    analytics_storage: v,
    ad_storage: v,
    ad_user_data: v,
    ad_personalization: v
  });
}

/* Mostra o banner apenas para quem ainda não escolheu */
(function(){
  var banner = document.getElementById("cookie-banner");
  if (banner && !localStorage.getItem("3lg_cookie_consent")) {
    setTimeout(function(){ banner.style.transform = "translateY(0)"; }, 800);
  }
})();

/* Pausa a animação do hero quando a aba não está visível */
document.addEventListener("visibilitychange", function(){
  const bg = document.querySelector(".hero-bg");
  bg && (bg.style.animationPlayState = document.hidden ? "paused" : "running");
});

/* v3: Rastreamento global de cliques no WhatsApp (GA4 + Meta) — cobre todas as paginas */
document.addEventListener("click", function(e){
  var a = e.target.closest && e.target.closest('a[href*="wa.me"], a[href*="api.whatsapp.com"]');
  if (!a || a.getAttribute("data-wa-tracked")) return;
  a.setAttribute("data-wa-tracked","1");
  try {
    if (typeof trackGA4Event === "function") trackGA4Event("click_whatsapp", {
      event_category: "whatsapp", event_label: location.pathname,
      link_url: a.href, link_text: (a.textContent||"").trim().slice(0,80)
    });
    if (window.fbq) fbq("track", "Contact");
  } catch(err){}
}, true);

/* v3.2: GA4 scroll_75 — profundidade de rolagem. Dispara uma unica vez por
   carregamento de pagina quando o usuario ultrapassa 75% da altura rolavel. */
(function(){
  var fired = false, ticking = false;
  function check(){
    ticking = false;
    if (fired) return;
    var doc = document.documentElement;
    var scrollable = doc.scrollHeight - window.innerHeight;
    if (scrollable <= 0) return;
    var pct = ((window.scrollY || doc.scrollTop) / scrollable) * 100;
    if (pct >= 75) {
      fired = true;
      try {
        if (typeof trackGA4Event === "function") trackGA4Event("scroll_75", {
          event_category: "engajamento", event_label: location.pathname
        });
      } catch(err){}
      window.removeEventListener("scroll", onScroll);
    }
  }
  function onScroll(){
    if (!ticking) { ticking = true; window.requestAnimationFrame(check); }
  }
  window.addEventListener("scroll", onScroll, { passive: true });
})();
