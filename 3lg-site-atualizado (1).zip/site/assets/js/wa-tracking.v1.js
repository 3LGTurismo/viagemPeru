/* 3LG Turismo — wa-tracking v1
   Rastreamento de cliques no WhatsApp para paginas que nao carregam main.v3.js
   (blog, sobre, depoimentos, termos-de-uso). Autossuficiente. */
(function () {
  "use strict";
  function send(name, params) {
    try {
      if (typeof window.trackGA4Event === "function") { window.trackGA4Event(name, params); return; }
      if (typeof window.gtag === "function") { window.gtag("event", name, params); return; }
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push(Object.assign({ event: name }, params));
    } catch (e) {}
  }
  document.addEventListener("click", function (e) {
    var a = e.target && e.target.closest && e.target.closest('a[href*="wa.me"], a[href*="api.whatsapp.com"]');
    if (!a || a.getAttribute("data-wa-tracked")) return;
    a.setAttribute("data-wa-tracked", "1");
    var p = {
      event_category: "whatsapp",
      event_label: location.pathname,
      link_url: a.href,
      link_text: (a.textContent || "").trim().slice(0, 80)
    };
    send("click_whatsapp", p);
    send("generate_lead", p);
    try { if (window.fbq) window.fbq("track", "Contact"); } catch (err) {}
  }, true);

  /* GA4 scroll_75 — profundidade de rolagem. Dispara uma unica vez por
     carregamento de pagina quando o usuario ultrapassa 75% da altura rolavel.
     Cobre as paginas que nao carregam main.v3.js (blog, sobre, depoimentos, termos-de-uso). */
  var scrollFired = false, scrollTicking = false;
  function checkScrollDepth(){
    scrollTicking = false;
    if (scrollFired) return;
    var doc = document.documentElement;
    var scrollable = doc.scrollHeight - window.innerHeight;
    if (scrollable <= 0) return;
    var pct = ((window.scrollY || doc.scrollTop) / scrollable) * 100;
    if (pct >= 75) {
      scrollFired = true;
      send("scroll_75", { event_category: "engajamento", event_label: location.pathname });
      window.removeEventListener("scroll", onScrollDepth);
    }
  }
  function onScrollDepth(){
    if (!scrollTicking) { scrollTicking = true; window.requestAnimationFrame(checkScrollDepth); }
  }
  window.addEventListener("scroll", onScrollDepth, { passive: true });
})();
