#!/usr/bin/env node
/**
 * migrate-images.js
 * ------------------------------------------------------------
 * Baixa todas as fotos do Unsplash usadas no site e as salva em
 * /assets/img/photos/, depois reescreve todos os arquivos .html
 * para apontar para os arquivos locais em vez de images.unsplash.com.
 *
 * Como usar:
 *   1. Coloque este arquivo na raiz do site (mesmo nível de "index.html").
 *   2. Rode:  node migrate-images.js
 *   3. Confira a pasta assets/img/photos/ e faça o deploy normalmente.
 *
 * Não precisa de nenhuma dependência além do Node.js (usa só "https" e "fs").
 * ------------------------------------------------------------
 */

const https = require("https");
const fs = require("fs");
const path = require("path");

// IDs únicos de fotos do Unsplash encontrados no site (extraídos automaticamente).
const PHOTO_IDS = [
  "photo-1436491865332-7a61a109cc05",
  "photo-1445019980597-93fa8acb246c",
  "photo-1449824913935-59a10b8d2000",
  "photo-1469854523086-cc02fe5d8800",
  "photo-1476514525535-07fb3b4ae5f1",
  "photo-1480074568708-e7b720bb3f09",
  "photo-1483729558449-99ef09a8c325",
  "photo-1488085061387-422e29b40080",
  "photo-1488646953014-85cb44e25828",
  "photo-1503220317375-aaad61436b1b",
  "photo-1506905925346-21bda4d32df4",
  "photo-1507525428034-b723cf961d3e",
  "photo-1511884642898-4c92249e20b6",
  "photo-1514282401047-d79a71a590e8",
  "photo-1518509562904-e7ef99cdcc86",
  "photo-1519046904884-53103b34b206",
  "photo-1519741497674-611481863552",
  "photo-1520250497591-112f2f40a3f4",
  "photo-1523751580351-ecaf438d7cb3",
  "photo-1527529482837-4698179dc6ce",
  "photo-1529156069898-49953e39b3ac",
  "photo-1537996194471-e657df975ab4",
  "photo-1544551763-46a013bb70d5",
  "photo-1548574505-5e239809ee19",
  "photo-1554123168-b400f9c806ca",
  "photo-1555881400-74d7acaacd8b",
  "photo-1559827260-dc66d52bef19",
  "photo-1561956021-947f09ae0101",
  "photo-1563729784474-d77dbb933a9e",
  "photo-1565514158740-064f34bd6cfd",
  "photo-1566073771259-6a8506099945",
  "photo-1570077188670-e3a8d69ac5ff",
  "photo-1575089976121-8ed7b2a54265",
  "photo-1589909202802-8f4aadce1849",
  "photo-1620141195936-07e57eccc6fd",
];

// Qualidade "canônica" para o download: 1600px de largura, alta qualidade, WebP.
const DOWNLOAD_QS = "w=1600&q=82&auto=format&fit=crop&fm=webp";

const OUT_DIR = path.join(__dirname, "assets", "img", "photos");
const SITE_ROOT = __dirname;

function download(url, destPath) {
  return new Promise((resolve, reject) => {
    https
      .get(url, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          return download(res.headers.location, destPath).then(resolve, reject);
        }
        if (res.statusCode !== 200) {
          return reject(new Error(`HTTP ${res.statusCode} para ${url}`));
        }
        const file = fs.createWriteStream(destPath);
        res.pipe(file);
        file.on("finish", () => file.close(resolve));
      })
      .on("error", reject);
  });
}

function walkHtmlFiles(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walkHtmlFiles(full, out);
    else if (entry.name.endsWith(".html")) out.push(full);
  }
  return out;
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });

  console.log(`Baixando ${PHOTO_IDS.length} fotos do Unsplash...`);
  for (const id of PHOTO_IDS) {
    const url = `https://images.unsplash.com/${id}?${DOWNLOAD_QS}`;
    const dest = path.join(OUT_DIR, `${id}.webp`);
    if (fs.existsSync(dest)) {
      console.log(`  já existe: ${id}.webp`);
      continue;
    }
    try {
      await download(url, dest);
      console.log(`  ok: ${id}.webp`);
    } catch (err) {
      console.error(`  FALHOU: ${id} -> ${err.message}`);
    }
  }

  console.log("\nReescrevendo referências nos arquivos .html...");
  const htmlFiles = walkHtmlFiles(SITE_ROOT);
  // Casa qualquer URL do Unsplash para um dos IDs conhecidos, com qualquer querystring
  // (inclusive com &amp; do HTML), e troca pelo caminho local.
  const pattern = new RegExp(
    `https://images\\.unsplash\\.com/(${PHOTO_IDS.join("|")})\\?[^"'\\s)]*`,
    "g"
  );

  let totalReplacements = 0;
  let filesChanged = 0;
  const preconnectPattern = /\n?<link rel="preconnect" href="https:\/\/images\.unsplash\.com"[^>]*>/g;

  for (const file of htmlFiles) {
    const original = fs.readFileSync(file, "utf-8");
    let count = 0;
    let updated = original.replace(pattern, (match, id) => {
      count++;
      return `/assets/img/photos/${id}.webp`;
    });
    if (count > 0) {
      const before = updated;
      updated = updated.replace(preconnectPattern, "");
      if (updated !== before) {
        console.log(`  ${path.relative(SITE_ROOT, file)}: preconnect para images.unsplash.com removido`);
      }
      fs.writeFileSync(file, updated, "utf-8");
      filesChanged++;
      totalReplacements += count;
      console.log(`  ${path.relative(SITE_ROOT, file)}: ${count} referência(s) atualizada(s)`);
    }
  }

  console.log(
    `\nConcluído: ${totalReplacements} referências reescritas em ${filesChanged} arquivo(s).`
  );
}

main().catch((err) => {
  console.error("Erro inesperado:", err);
  process.exit(1);
});
