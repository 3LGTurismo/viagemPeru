#!/usr/bin/env python3
"""
Envia todas as URLs do sitemap.xml para o IndexNow (Bing, Yandex, Seznam, Naver etc).

COMO USAR
---------
1. Suba o arquivo de chave para a raiz do site (já criado neste pacote):
   083f7cf2b52c410a84c475296015da06.txt
   Ele deve ficar acessível em:
   https://www.3lg.com.br/083f7cf2b52c410a84c475296015da06.txt

2. Rode este script sempre que publicar ou atualizar páginas:
   python3 submit_indexnow.py

3. Para enviar só algumas URLs específicas (ex: depois de editar 1 página):
   python3 submit_indexnow.py https://www.3lg.com.br/blog/novo-post/

Documentação oficial: https://www.bing.com/indexnow
"""
import re
import sys
import json
import urllib.request

HOST = "www.3lg.com.br"
KEY = "083f7cf2b52c410a84c475296015da06"
KEY_LOCATION = f"https://{HOST}/{KEY}.txt"
SITEMAP_PATH = "../sitemap.xml"
ENDPOINT = "https://api.indexnow.org/indexnow"


def load_urls_from_sitemap(path=SITEMAP_PATH):
    with open(path, encoding="utf-8") as f:
        content = f.read()
    return re.findall(r"<loc>(.*?)</loc>", content)


def submit(urls):
    if not urls:
        print("Nenhuma URL para enviar.")
        return

    payload = {
        "host": HOST,
        "key": KEY,
        "keyLocation": KEY_LOCATION,
        "urlList": urls,
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        ENDPOINT,
        data=data,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            print(f"Enviado com sucesso. Status: {resp.status}")
            print(f"URLs enviadas: {len(urls)}")
    except urllib.error.HTTPError as e:
        # 200/202 = sucesso, 400/403/422/429 = ver docs do IndexNow
        print(f"Erro HTTP {e.code}: {e.read().decode(errors='ignore')}")
    except Exception as e:
        print(f"Falha ao enviar: {e}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        urls_to_send = sys.argv[1:]
    else:
        urls_to_send = load_urls_from_sitemap()
        print(f"{len(urls_to_send)} URLs encontradas no sitemap.xml")

    submit(urls_to_send)
